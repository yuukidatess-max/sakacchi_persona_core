console.log('Demo frontend loaded');
async function loadEvents(){
  const res = await fetch('/api/ping');
  const j = await res.json();
  document.getElementById('list').innerText = 'Server: ' + j.status + ' (v ' + j.version + ')';
}
document.addEventListener('DOMContentLoaded', loadEvents);
