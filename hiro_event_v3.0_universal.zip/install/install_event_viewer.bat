@echo off
echo Installing Hiro Event Viewer v3.0.0 (demo)...
set BASE=%~dp0
echo Base folder: %BASE%
echo Starting server...
start "" python "%BASE%server\server.py"
timeout /t 2 >nul
start "" "%BASE%frontend\index.html"
echo Done.
pause
