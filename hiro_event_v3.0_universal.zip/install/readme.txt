Hiro Event Viewer v3.0.0 - Demo scaffold
------------------------------
This package is a demo scaffold for v3.0.0.
Run install\install_event_viewer.bat to start the demo server and open the frontend.
