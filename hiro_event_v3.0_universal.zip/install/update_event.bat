@echo off
echo Updating Hiro Event Viewer v3.0.0 (demo)...
set BASE=%~dp0
echo Logging update to changelog...
echo %date%,v3.0.0,manual update >> "%BASE%changelog.csv"
echo Update complete.
pause
