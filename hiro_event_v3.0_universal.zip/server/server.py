# server.py - minimal Flask scaffold for Hiro Event Viewer v3.0 (demo)
from flask import Flask, jsonify, send_from_directory
import pathlib, json
app = Flask(__name__, static_folder='frontend')

@app.route('/api/ping')
def ping():
    return jsonify({"status":"ok","version":"v3.0.0"})

@app.route('/')
def index():
    return send_from_directory('frontend', 'index.html')

if __name__ == '__main__':
    print('Starting demo server on http://127.0.0.1:5000')
    app.run(host='127.0.0.1', port=5000)
