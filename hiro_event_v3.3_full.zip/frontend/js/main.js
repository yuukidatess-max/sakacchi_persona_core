console.log('Kazenouta v3.3 frontend loaded');
async function loadEvents(){
  try{
    const res = await fetch('/api/events');
    const j = await res.json();
    const list = document.getElementById('events-list');
    list.innerHTML='';
    j.events.forEach(ev=>{
      const d=document.createElement('div'); d.className='event';
      d.innerHTML='<div class="ev-title">'+ev.title+'</div><div class="ev-meta">'+ev.date+' '+ev.time+' — '+ev.facility+'</div><div class="ev-summary">'+ev.summary+'</div>';
      const bar=document.createElement('div'); bar.className='conf-bar';
      const fill=document.createElement('div'); fill.className='conf-fill'; fill.style.width=(ev.confidence||60)+'%';
      bar.appendChild(fill); d.appendChild(bar); list.appendChild(d);
    });
  }catch(e){
    console.error(e);
  }
}
async function fetchChronicle(){ try{ const r=await fetch('/api/chronicle'); if(!r.ok) throw ''; const txt=await r.text(); document.getElementById('chronicle-content').innerText=txt;}catch(e){document.getElementById('chronicle-content').innerText='No chronicle.'}}
async function fetchBridge(){ try{ const r=await fetch('/api/bridge/report'); if(!r.ok) throw ''; const txt=await r.text(); document.getElementById('bridge-content').innerText=txt;}catch(e){document.getElementById('bridge-content').innerText='No bridge report.'}}
async function askTone(){ const persona=document.getElementById('persona-select').value; const prompt=document.getElementById('prompt').value; const r=await fetch('/api/tone',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({persona,prompt})}); const j=await r.json(); document.getElementById('ai-persona').innerText = j.persona==='saka'?'大賢者サカっち':'ラファエル'; document.getElementById('ai-msg').innerText=j.msg; }
document.getElementById('ask-tone').addEventListener('click',askTone);
document.addEventListener('DOMContentLoaded',()=>{loadEvents(); fetchChronicle(); fetchBridge();});
