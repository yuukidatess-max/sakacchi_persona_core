@echo off
rem install_event_viewer.bat - v3.3 full installer
set "BASE=%~dp0"
set "ROOT=%BASE%.."
echo Installing Kazenouta v3.3-full...
pushd "%ROOT%"
rem start server (requires python)
start "" python "%ROOT%server\server.py"
timeout /t 2 >nul
start "" "%ROOT%frontend\index.html"
popd
echo Installed.
pause
