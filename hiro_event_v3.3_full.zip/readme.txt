Kazenouta : Sanfrecce - v3.3-full
-----------------------------------
This package is a preview/full scaffold containing:
 - Frontend with Sanfrecce symbol UI, AI speech bar, events list with confidence bars
 - Flask server with tone endpoint, events and chronicle APIs
 - BridgeForge validation report and patch diff
 - Creation chronicle archive

Usage:
 1. Extract the ZIP to a folder.
 2. Run install\install_event_viewer.bat (requires Python).
 3. Frontend auto-opens; if not, open frontend/index.html in a browser.

Generated at: 2025-11-10T20:24:11.836232
