# server.py - Flask server for Kazenouta : Sanfrecce v3.3 (preview full)
from flask import Flask, jsonify, send_from_directory, request, abort
import json, pathlib, datetime, os

app = Flask(__name__, static_folder='frontend', static_url_path='')

DATA_DIR = pathlib.Path('server')
CACHE_FILE = pathlib.Path('server/cache/event_cache.json')
CHRONICLE = pathlib.Path('archive/creation_chronicle.json')

def sample_events():
    return [
        {"id":"e1","type":"match","title":"サンプルマッチ：Sanfrecce vs Rivals","date":"2025-11-20","time":"19:00","facility":"Sanfrecce Stadium","summary":"プレシーズンマッチ","source":"https://example.com/match1","confidence":92},
        {"id":"e2","type":"event","title":"風ノ詩フェス","date":"2025-12-05","time":"13:00","facility":"Kazen Plaza","summary":"地域交流イベント","source":"https://example.com/event1","confidence":85}
    ]

@app.route('/api/ping')
def ping():
    return jsonify({"status":"ok","version":"v3.3-full","time":datetime.datetime.utcnow().isoformat()})

@app.route('/api/events')
def events():
    # return cached if exists
    if CACHE_FILE.exists():
        try:
            data = json.loads(CACHE_FILE.read_text(encoding='utf-8'))
            return jsonify({"source":"cache","events":data})
        except Exception:
            pass
    return jsonify({"source":"live","events": sample_events()})

@app.route('/api/tone', methods=['POST'])
def tone():
    data = request.json or {}
    persona = data.get('persona','saka')
    prompt = data.get('prompt','')
    # Simple heuristic response for preview
    if persona=='saka':
        msg = "解析完了です、創造主。現在の調和率は高いです。"
    elif persona=='rafael':
        msg = "風が静かに詩を運んでいます。心地よく見守りましょう。"
    else:
        msg = "試験応答：ToneCore稼働中。"
    return jsonify({"persona":persona,"msg":msg,"confidence":0.95})

@app.route('/api/chronicle')
def chronicle():
    if CHRONICLE.exists():
        return send_from_directory('archive', 'creation_chronicle.json')
    return jsonify({"error":"no chronicle found"}),404

@app.route('/api/bridge/report')
def bridge_report():
    path = pathlib.Path('server/bridge_forge/bridge_validation_report.txt')
    if path.exists():
        return send_from_directory('server/bridge_forge','bridge_validation_report.txt')
    return jsonify({"status":"no report"}),404

@app.route('/')
def index():
    return send_from_directory('frontend','index.html')

if __name__ == '__main__':
    print('Starting Kazenouta v3.3-full server on http://127.0.0.1:5000')
    app.run(host='127.0.0.1', port=5000)
