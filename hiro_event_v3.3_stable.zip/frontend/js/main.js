console.log('Kazenouta v3.3-stable frontend loaded');
async function safeFetch(url, opts){
  try{
    const r = await fetch(url, opts);
    if(!r.ok) throw new Error('http '+r.status);
    return r;
  }catch(e){ console.warn('fetch failed',url,e); throw e; }
}
async function loadEvents(){
  try{
    const res = await safeFetch('/api/events');
    const j = await res.json();
    const list = document.getElementById('events-list');
    list.innerHTML='';
    j.events.forEach(ev=>{
      const d=document.createElement('div'); d.className='event';
      d.innerHTML='<div class="ev-title" title="'+ev.title+'">'+(ev.title.length>60?ev.title.slice(0,57)+'...':ev.title)+'</div><div class="ev-meta">'+ev.date+' '+ev.time+' — '+ev.facility+'</div><div class="ev-summary">'+ev.summary+'</div>';
      const bar=document.createElement('div'); bar.className='conf-bar';
      const fill=document.createElement('div'); fill.className='conf-fill'; fill.style.width=(ev.confidence||60)+'%';
      bar.appendChild(fill); d.appendChild(bar); list.appendChild(d);
      d.addEventListener('click',()=>{ alert(ev.title+'\\n\\n'+ev.summary+'\\n\\nSource: '+ev.source); });
    });
  }catch(e){
    document.getElementById('events-list').innerText='Failed to load events.';
  }finally{
    document.getElementById('loading').style.display='none';
    document.getElementById('app').style.display='block';
  }
}
async function fetchChronicle(){ try{ const r=await safeFetch('/api/chronicle'); const txt=await r.text(); document.getElementById('chronicle-content').innerText=txt;}catch(e){document.getElementById('chronicle-content').innerText='No chronicle.'}}
async function fetchBridge(){ try{ const r=await safeFetch('/api/bridge/report'); const txt=await r.text(); document.getElementById('bridge-content').innerText=txt;}catch(e){document.getElementById('bridge-content').innerText='No bridge report.'}}
async function askTone(){ try{ const persona=document.getElementById('persona-select').value; const prompt=document.getElementById('prompt').value; const r=await fetch('/api/tone',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({persona,mode:'stable',prompt})}); const j=await r.json(); document.getElementById('ai-persona').innerText = j.persona==='saka'?'大賢者サカっち':'ラファエル'; document.getElementById('ai-msg').innerText=j.msg; }catch(e){document.getElementById('ai-msg').innerText='ToneCore unreachable.'}}
async function clearCache(){ try{ const r=await fetch('/api/cache/clear',{method:'POST'}); const j=await r.json(); alert('Cache cleared: '+(j.status||j.error)); loadEvents(); }catch(e){ alert('Failed to clear cache'); } }
document.getElementById('ask-tone').addEventListener('click',askTone);
document.getElementById('clear-cache').addEventListener('click',clearCache);
document.addEventListener('DOMContentLoaded',()=>{loadEvents(); fetchChronicle(); fetchBridge();});