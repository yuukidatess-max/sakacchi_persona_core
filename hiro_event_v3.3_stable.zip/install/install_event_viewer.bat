@echo off
rem install_event_viewer.bat - v3.3 stable installer (fixed paths)
set "BASE=%~dp0"
set "ROOT=%BASE%.."
echo Installing Kazenouta v3.3-stable...
rem push to project root
pushd "%ROOT%"
rem attempt to start python server; requires python in PATH
start "" python "%ROOT%server\server.py"
timeout /t 2 >nul
rem open frontend using the project root
start "" "%ROOT%frontend\index.html"
popd
echo Installed.
pause
