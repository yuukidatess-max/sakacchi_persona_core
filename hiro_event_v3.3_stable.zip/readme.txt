Kazenouta : Sanfrecce - v3.3-stable
-----------------------------------
Stable build for Kazenouta : Sanfrecce (v3.3-stable).
Includes:
 - corrected install batch (paths fixed)
 - Flask server with port fallback, access logs, cache clear endpoint
 - Frontend with loading screen, events list, AI bar, chronicle and bridge report
 - Build check and bridge forge placeholders

Usage:
 1. Extract the ZIP to a folder.
 2. Run install\install_event_viewer.bat (requires Python in PATH).
 3. If browser not opened automatically, open http://127.0.0.1:5000/

Generated at: 2025-11-10T20:54:15.338347
