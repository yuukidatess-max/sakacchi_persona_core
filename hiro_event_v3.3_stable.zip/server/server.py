# server.py - Flask server for Kazenouta : Sanfrecce v3.3-stable
from flask import Flask, jsonify, send_from_directory, request, abort
import json, pathlib, datetime, os, socket
app = Flask(__name__, static_folder='frontend', static_url_path='')

BASE = pathlib.Path('.').resolve()
CACHE_FILE = BASE / 'server' / 'cache' / 'event_cache.json'
CHRONICLE = BASE / 'archive' / 'creation_chronicle.json'
LOG_DIR = BASE / 'server' / 'log'
LOG_DIR.mkdir(parents=True, exist_ok=True)
ACCESS_LOG = LOG_DIR / 'access_log.txt'
STARTUP_LOG = LOG_DIR / 'startup_log.txt'
CONFIG = BASE / 'server' / 'config.json'

def write_startup(msg):
    with STARTUP_LOG.open('a', encoding='utf-8') as f:
        f.write(f"[{datetime.datetime.utcnow().isoformat()}] {msg}\n")

def log_access(path, ip):
    with ACCESS_LOG.open('a', encoding='utf-8') as f:
        f.write(f"[{datetime.datetime.utcnow().isoformat()}] {ip} {path}\n")

def sample_events():
    return [
        {"id":"e1","type":"match","title":"サンプルマッチ：Sanfrecce vs Rivals","date":"2025-11-20","time":"19:00","facility":"Sanfrecce Stadium","summary":"プレシーズンマッチ","source":"https://example.com/match1","confidence":92},
        {"id":"e2","type":"event","title":"風ノ詩フェス","date":"2025-12-05","time":"13:00","facility":"Kazen Plaza","summary":"地域交流イベント","source":"https://example.com/event1","confidence":85}
    ]

@app.before_request
def before():
    try:
        log_access(request.path, request.remote_addr or 'local')
    except Exception:
        pass

@app.route('/api/ping')
def ping():
    cfg = {}
    if CONFIG.exists():
        try:
            cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
        except Exception:
            cfg = {}
    return jsonify({"status":"running","version":cfg.get('version','v3.3-stable'),"uptime":datetime.datetime.utcnow().isoformat(),"mode":cfg.get('mode','stable')})

@app.route('/api/events')
def events():
    # try cache
    if CACHE_FILE.exists():
        try:
            data = json.loads(CACHE_FILE.read_text(encoding='utf-8'))
            return jsonify({"source":"cache","events":data})
        except Exception:
            # attempt auto-regenerate
            try:
                with CACHE_FILE.open('w',encoding='utf-8') as f:
                    json.dump(sample_events(), f, ensure_ascii=False, indent=2)
            except Exception:
                pass
    # fallback
    return jsonify({"source":"live","events": sample_events()})

@app.route('/api/cache/clear', methods=['POST'])
def cache_clear():
    try:
        if CACHE_FILE.exists():
            CACHE_FILE.unlink()
        return jsonify({"status":"cleared"})
    except Exception as e:
        return jsonify({"error":str(e)}),500

@app.route('/api/tone', methods=['POST'])
def tone():
    data = request.json or {}
    persona = data.get('persona','saka')
    mode = data.get('mode','stable')
    # stable mode enforced
    if persona=='saka':
        msg = "解析完了しました。調和率は高いです。今日の流れは穏やかです。"
    elif persona=='rafael':
        msg = "風は詩を運んでいます。静かに見守りましょう。"
    else:
        msg = "試験応答：ToneCore稼働中。"
    return jsonify({"persona":persona,"msg":msg,"confidence":0.95})

@app.route('/api/chronicle')
def chronicle():
    if CHRONICLE.exists():
        return send_from_directory('archive', CHRONICLE.name)
    return jsonify({"error":"no chronicle found"}),404

@app.route('/api/bridge/report')
def bridge_report():
    path = BASE / 'server' / 'bridge_forge' / 'bridge_validation_report.txt'
    if path.exists():
        return send_from_directory(str(path.parent), path.name)
    return jsonify({"status":"no report"}),404

@app.route('/')
def index():
    return send_from_directory('frontend','index.html')

def find_free_port(start=5000, max_port=5010):
    for p in range(start, max_port+1):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(('127.0.0.1', p))
                return p
            except OSError:
                continue
    return None

if __name__ == '__main__':
    # read config
    cfg = {}
    if CONFIG.exists():
        try:
            cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
        except Exception:
            cfg = {}
    preferred = cfg.get('port',5000)
    port = preferred
    # check bind
    try:
        s=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(('127.0.0.1',port))
        s.close()
    except Exception:
        alt = find_free_port(preferred, preferred+10)
        if alt:
            port = alt
    write_startup(f"Starting server on port {port}")
    print(f'Starting Kazenouta v3.3-stable on http://127.0.0.1:{port}')
    app.run(host='127.0.0.1', port=port)
