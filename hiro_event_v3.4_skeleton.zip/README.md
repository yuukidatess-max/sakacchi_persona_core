# サカっち V3.4 Skeleton - Kazenouta

このディレクトリは V3.4 開発のためのプロジェクト骨格（スケルトン）です。
目的：persona と emotion_state の統合、および bridge_sync による自動継承フローを組み込む基盤を提供する。

重要ファイル:
- /server/bridge_forge/persona_integrated_v3.4.json  (統合人格ファイル)
- /server/bridge_forge/bridge_validation_report.txt  (文脈要約)
- /server/bridge_forge/bridge_sync.py               (同期スクリプト雛形)
- /frontend/*                                      (簡易UI)
- /install/install_event_viewer.bat                (Windows向け簡易インストーラ雛形)
