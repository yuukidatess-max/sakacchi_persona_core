#!/usr/bin/env python3
"""bridge_sync.py - skeleton for automatic bridge merging and export.
Responsibilities:
- Detect persona_context.json and emotion_state.json
- Merge into persona_integrated_vX.Y.json
- Produce bridge_validation_report.txt and update manifest
"""
import json, sys
from pathlib import Path

BRIDGE = Path(__file__).resolve().parent
def merge(persona_path, emotion_path, out_path):
    p = json.loads(persona_path.read_text(encoding='utf-8'))
    e = json.loads(emotion_path.read_text(encoding='utf-8'))
    merged = {
        "version": out_path.stem.split('_')[-1].replace('v',''),
        "inherits": [persona_path.name, emotion_path.name],
        "persona": {
            "name": p.get('base_persona', {}).get('name','サカっち'),
            "role": p.get('base_persona', {}).get('role','開発支援AI'),
            "core_traits": p.get('base_persona', {}).get('traits', []),
            "modes": p.get('modes', {}),
            "emotion_state": e.get('affinity', {})
        },
        "carry_over": e.get('carry_over', {})
    }
    out_path.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"Merged -> {out_path}")
    return merged

def main():
    persona_path = BRIDGE / 'persona_context.json'
    emotion_path = BRIDGE / 'emotion_state.json'
    out_path = BRIDGE / 'persona_integrated_v3.4.json'
    if not persona_path.exists() or not emotion_path.exists():
        print('Missing source files. Place persona_context.json and emotion_state.json in bridge_forge/')
        sys.exit(1)
    merge(persona_path, emotion_path, out_path)

if __name__ == '__main__':
    main()
