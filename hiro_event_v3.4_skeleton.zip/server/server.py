#!/usr/bin/env python3
"""Minimal server entrypoint for V3.4 skeleton.
This is a placeholder — expand with your actual server logic.
"""
import json, os
from pathlib import Path

BASE = Path(__file__).resolve().parent
CFG = BASE / "config.json"
BRIDGE = BASE / "bridge_forge"

def load_config():
    if CFG.exists():
        return json.loads(CFG.read_text(encoding='utf-8'))
    return {"mode": "development"}

def load_persona():
    pfile = BRIDGE / "persona_integrated_v3.4.json"
    if pfile.exists():
        return json.loads(pfile.read_text(encoding='utf-8'))
    return None

def main():
    cfg = load_config()
    persona = load_persona()
    print(f"Server starting (mode={cfg.get('mode')})")
    if persona:
        print(f"Loaded persona: {persona.get('persona', {}).get('name')}")


if __name__ == '__main__':
    main()
